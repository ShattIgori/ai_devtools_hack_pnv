#!/usr/bin/env python3
"""
OpenAPI Test Generator - Main module (Legacy CLI)

Этот файл является устаревшим CLI-интерфейсом. 
Основная логика перенесена в FastAPI приложение в `app.py`.
"""

import sys

def main():
    """
    Основная функция, которая теперь просто информирует пользователя о новом способе запуска.
    """
    print("=" * 70)
    print("🚀 OpenAPI Test Generator - Устаревший CLI")
    print("=" * 70)
    print("\n✅ Вся основная логика была перенесена в FastAPI приложение.")
    print("   Это было сделано в рамках выполнения Задач 5 и 6.")
    print("\n   Для запуска бэкенд-сервера, пожалуйста, используйте один из следующих методов:")
    print("\n   1. Локальный запуск (требует установленных зависимостей):")
    print("      uvicorn app:app --host 0.0.0.0 --port 8000 --reload")
    print("\n   2. Запуск через Docker (рекомендуемый способ):")
    print("      docker-compose up --build")
    print("\n   После запуска, API будет доступно по адресу http://localhost:8000/docs")
    print("=" * 70)

if __name__ == "__main__":
    main()
